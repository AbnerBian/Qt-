#include "typewidget.h"
#include<QMessageBox>

typeWidget::typeWidget(QWidget *parent) : QWidget(parent)
{
    setWindowTitle("成绩录入");
    QGridLayout *gridlayout=new QGridLayout();
    //输入学号
    id=new QLineEdit;
    id_label=new QLabel;
    id_label->setText("学号");
    //输入姓名
    name=new QLineEdit;
    name_label=new QLabel;
    name_label->setText("姓名");
    //输入专业
    profession=new QLineEdit;
    profession_label=new QLabel;
    profession_label->setText("专业");
    //输入班级
    grade=new QLineEdit;
    grade_label=new QLabel;
    grade_label->setText("班级");
    //入学年份
    year=new QLineEdit;
    year_label=new QLabel;
    year_label->setText("入学年份");

    //联系电话
    phone=new QLineEdit;
   phone_label=new QLabel;
    phone_label->setText("联系电话");
    //嵌入式系统
    embeded_system=new QLineEdit;
    embeded_system_label=new QLabel;
    embeded_system_label->setText("嵌入式系统");
    //微波技术与天线
    microwave=new QLineEdit;
    microwave_label=new QLabel;
    microwave_label->setText("微波技术与天线");
    //通信原理
    communication=new QLineEdit;
    communication_label=new QLabel;
    communication_label->setText("通信原理");
    //科技英语
    english=new QLineEdit;
    english_label=new QLabel;
    english_label->setText("科技英语");
    //提交按钮
    QPushButton*submit=new QPushButton;
    submit->setText("提交");
    gridlayout->addWidget(id_label,0,0);
    gridlayout->addWidget(id,0,1);
    gridlayout->addWidget(name_label,1,0);
    gridlayout->addWidget(name,1,1);
    gridlayout->addWidget(profession_label,2,0);
    gridlayout->addWidget(profession,2,1);
    gridlayout->addWidget(grade_label,3,0);
    gridlayout->addWidget(grade,3,1);
    gridlayout->addWidget(year_label,4,0);
    gridlayout->addWidget(year,4,1);
    gridlayout->addWidget(phone_label,5,0);
    gridlayout->addWidget(phone,5,1);
    gridlayout->addWidget(embeded_system_label,6,0);
    gridlayout->addWidget(embeded_system,6,1);
    gridlayout->addWidget(microwave_label,7,0);
    gridlayout->addWidget(microwave,7,1);
    gridlayout->addWidget(communication_label,8,0);
    gridlayout->addWidget(communication,8,1);
    gridlayout->addWidget(english_label,9,0);
    gridlayout->addWidget(english,9,1);
    gridlayout->addWidget(submit,10,1);
    this->setLayout(gridlayout);
    connect(submit,&QPushButton::clicked,this,typeWidget::submit_info);

}

void typeWidget::submit_info()
{

    QList<QString>courses;
    QList<QString>scores;
    courses.clear();
    scores.clear();
    courses.append("嵌入式系统设计");
    courses.append("微波技术与天线");
    courses.append("通信原理");
    courses.append("科技英语");
    scores.append(embeded_system->text());
    scores.append(microwave->text());
    scores.append(communication->text());
    scores.append(english->text());
    QString Sname=name->text();
    QString Sid=id->text();
    QString Sprofession=profession->text();
    QString Sgrade=grade->text();
    QString Syear=year->text();
    QString Sphone=phone->text();
//发送信号
    if(Sid.isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("学号不能为空！！！"));
    }else if(Sname.isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("姓名不能为空！！！"));
    }else if(Sprofession.isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("专业不能为空！！！"));
    }else if(Sgrade.isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("班级不能为空！！！"));
    }else if(Syear.isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("入学年份不能为空！！！"));
    }else if(Sphone.isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("联系电话不能为空！！！"));
    }else if(embeded_system->text().isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("成绩不能为空！！！"));
    }else if(microwave->text().isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("成绩不能为空！！！"));
    }else if(communication->text().isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("成绩不能为空！！！"));
    }else if(english->text().isEmpty())
    {
        QMessageBox::critical(this,tr("错误"),tr("成绩不能为空！！！"));
    }
    else
    {
        QMessageBox::information(this,tr("成功"),tr("恭喜你,录入完成"));
        this->hide();
        emit type_info(courses,scores,Sname,Sid,Sprofession,Sgrade,Syear,Sphone);

    }







}








