#ifndef SCOREWINDOW_H
#define SCOREWINDOW_H
#include<typewidget.h>
#include <QMainWindow>
#include<QtSql>
#include <QFileDialog>
#include<QDebug>
#include <QMessageBox>
#include<QList>
#include <QSqlQuery>
#include<QPushButton>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    QSqlDatabase Connect_DB();
    void queryStudentInfo(QString  str);
    void calculatePoints();
    void updateInfoWindow();
    void draw_table();
    void init();
    void get_Stud_Score(QString);
    float convert_grade_to_GPA(QString);
    void import_data(QStringList );
    void getCourseIDthroughCoureName(QString);//courseid内容存储在类的字段中
    void insert_t_stud_course_info(QString,QString,QString,QString,QString);//执行插入t_stud_course_info表的操作
    void update_t_stud_info(QString,QString,QString,QString,QString,QString);
    void insert_t_stud_info(QString,QString,QString,QString,QString,QString);
    void setRightEdit(QString,QString,QString,QString);
    bool Check_duplicate(QString,QString);
    // Model;
    ~MainWindow();

private slots:


    void on_import_file_triggered();

    void on_btnQuery_clicked();

    void on_type_grade_clicked();
    void type_info_processing(QList<QString>,QList<QString>,QString,QString,QString,QString,QString,QString);

private:
    QList<QString> credit;//学分
    QList<QString> GPA; //绩点
    QList<QString>course;//课程
    QList<QString>grade;    //成绩
    QString name;       //学生姓名
    QString profession;//专业
    QString id; //学号
    QString mean_GPA;//平均绩点
    QString Sclass;//班级
    QList<QString>import_course;//导入的课程列表
    QList<QString>import_student_info;
    QString courseID;//课程id
    int mode=0;//0表示学号或个人，1表示全部
    QList<QString>all_name;

    Ui::MainWindow *ui;
    QSqlDatabase db;
    QString queryResult;
    typeWidget *typewidget;
};

#endif // MAINWINDOW_H
