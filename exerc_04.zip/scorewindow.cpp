#include "scorewindow.h"
#include "ui_scorewindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    typewidget=new typeWidget;
    typewidget->hide();
    setWindowIcon(QIcon(":/root/black Box.png"));
    setWindowTitle("绩点计算器");
    this->resize(QSize(1041,629));
    db=Connect_DB();

    init();
    draw_table();
    connect(typewidget,typeWidget::type_info,this,MainWindow::type_info_processing);

}

MainWindow::~MainWindow()
{
    delete ui;
}
QSqlDatabase MainWindow::Connect_DB()
{
    //数据库配置信息
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("rm-dj1g5wx9j769j9hhpo.mysql.rds.aliyuncs.com");
        db.setDatabaseName("score");
        db.setUserName("abner");
        db.setPassword("Mingge666");
        if (!db.open())
        {
            qDebug() << "Failed to connect to mysql";
        }

        return db;
}

//setstylesheet
//textedit

void MainWindow::on_import_file_triggered()
{

    //打开csv，导入数据库
    QString fileName = QFileDialog::getOpenFileName(this,
          tr("import csv file"), "/home", tr(" Excel(*.csv)"));
    qDebug()<<fileName;
    QDir dir = QDir::current();
    QFile file(dir.filePath(fileName));
    if(!file.open(QIODevice::ReadOnly))
         qDebug()<<"OPEN FILE FAILED";
    QTextStream * out = new QTextStream(&file);//文本流
    QStringList temp = out->readAll().split("\n");//每行以\n区分
    for(int i = 0 ; i < temp.count()-1 ; i++)
    {

         QStringList temprow = temp.at(i).split(",");//一行中的单元格以，区分
         //导入数据库
         import_data(temprow);
         //qDebug()<<temprow;
    }
    file.close();
}

void MainWindow::import_data(QStringList data)
{
    //存放要存储的课程名
    if(import_course.isEmpty())
    {
        for(int i=5;i<data.size();i++)
        {
            import_course.append(data.at(i));

        }
        //去除最后一个\r
        import_course.last()=import_course.last().left(import_course.last().indexOf("\r"));
    }else
    {
            for(int i=1;i<data.size();i++)
            {
                import_student_info.append(data.at(i));

            }
            //去除最后一个\r
            import_student_info.last()=import_student_info.last().left(import_student_info.last().indexOf("\r"));
            id=import_student_info.at(0);
            name=import_student_info.at(1);
        //需要什么：courseID，学号，成绩，
            qDebug()<<import_course.size();
            for(int i=0;i<import_course.size();i++)
            {   //courseid在couseid字段
                getCourseIDthroughCoureName(import_course.at(i));

                    if(Check_duplicate(id,courseID))
                     {
                        insert_t_stud_course_info(id,courseID,import_student_info.at(i+4),"2017-2018","1");
                     }
                }

        import_student_info.clear();
    }


}
void MainWindow::getCourseIDthroughCoureName(QString coureName)
{
    if(!db.isOpen())
    {
        db.open();
    }
    QString query_str=QString("select courseID from t_courses where courseName='%1'").arg(coureName);
    qDebug()<<query_str;
    QSqlQuery query(query_str);
    while (query.next()) {
        courseID=query.value(0).toString();
    }
}
void MainWindow::insert_t_stud_course_info(QString id, QString courseID, QString score, QString year, QString term)
{
    QString query_str=QString("insert into t_stud_course_info (scNumber,scCourseID,scScores,scYear,scTerm)"
                          "values"
                          "(%1,%2,%3,%4,%5)").arg(id).arg(courseID).arg(score).arg(year).arg(term);

    qDebug()<<query_str;
    if(!db.isOpen())
    {
        db.open();
    }
    QSqlQuery insert(query_str);

}
void MainWindow::insert_t_stud_info(QString id, QString name, QString major, QString sClass, QString year, QString phone)
{
    if(!db.isOpen())
    {
        db.open();
    }
    //若是学生表里没有，则添加学生
    QString query_str=QString("insert into t_stud_info (sNumber,sName,sMajor,sClass,sEnrolledYear,sPhone)"
                              "values"
                              "(%1,%2,%3,%4,%5,%6)").arg(id).arg(name).arg(major).arg(sClass).arg(year).arg(phone);
    qDebug()<<query_str;
    QSqlQuery insert(query_str);
}
void MainWindow::update_t_stud_info(QString id, QString name, QString major, QString sClass, QString year, QString phone)
{
    if(!db.isOpen())
    {
        db.open();
    }
    //更新通过学号
    QString query_str=QString("update t_stud_info set sName=%1,sMajor=%2,sClass=%3,sEnrolledYear=%4,sPhone=%5"
                              " where sNumber=%6")
            .arg(name).arg(major).arg(sClass).arg(year).arg(phone).arg(id);
    QSqlQuery update(query_str);

}

void MainWindow::on_btnQuery_clicked()
{
    if(db.isOpen())
    {
        db.close();
    }
    if(!db.open())
    {
        QMessageBox::critical(this,tr("错误"),tr("无法连接数据库！\n请检查数据库连接配置"));
        return;
    }else
    {
        mode=0;
        QString str;
        if(ui->radioStNumber->isChecked())
        {
            str=QString("where sNumber='%1'").arg(ui->edtInput->text());
        }else if(ui->radioStName->isChecked())
        {
            str=QString("where sName='%1'").arg(ui->edtInput->text());
        }
        else if(ui->radioStAll->isChecked())
        {
            mode=1;
            str="";
        }

        queryStudentInfo(str);
        switch(mode)
         {
             case 0://非全部模式
                ui->textEdit->clear();
                get_Stud_Score(str);
                calculatePoints();
                updateInfoWindow();

                 break;
             case 1://全部模式
                ui->textEdit->clear();
                 get_Stud_Score(str);
                 //找出所有同学
                 QString query_all_stud="select sName from t_stud_info";
                 QSqlQuery query(query_all_stud);

                 while (query.next()) {

                     QString name=query.value(0).toString();

                     all_name.append(name);

                 }
                 for(int i=0;i<all_name.size();i++)
                 {
                     //分别绘制出每位同学对应的表格
                     name=all_name.at(i);
                     str=QString("where sName='%1'").arg(name);
                     get_Stud_Score(str);
                     calculatePoints();
                     updateInfoWindow();
                 }
                 all_name.clear();
                    break;
         }
         db.close();

    }
}
void MainWindow::get_Stud_Score(QString str)
{

    if(!db.isOpen())
    {
        db.open();
    }
    QString queryStr=QString("select t_stud_info.sName as '姓名',t_courses.courseName as '课程名称',"
                     "t_stud_course_info.scScores as '成绩',t_courses.courseCredit as '学分'"
                     "from"
                     " t_stud_course_info inner join t_courses on t_stud_course_info.scCourseID=t_courses.courseID "
                     "inner join t_stud_info on t_stud_info.sNumber=t_stud_course_info.scNumber "
                     "%1"
                     " order by t_stud_course_info.scNumber"";").arg(str);
    qDebug()<<queryStr;
    course.clear();
    grade.clear();
    credit.clear();
    QSqlQuery query(queryStr);

    while (query.next()) {
        name=query.value(0).toString();
        QString course_name = query.value(1).toString();
        QString Sclass=query.value(2).toString();
        QString credit_number=query.value(3).toString();
        course.append(course_name);
        grade.append(Sclass);
        credit.append(credit_number);

    }
}

float MainWindow::convert_grade_to_GPA(QString k)
{
    float GPA;
    if(k=="优秀")
    {
        GPA=4.00;
        return GPA;
    }else if(k=="良好")
    {
        GPA=3.50;
        return GPA;
    }else if(k=="中等")
    {
        GPA=2.5;
        return GPA;
    }else if(k=="及格")
    {

        GPA=1.5;
        return GPA;
    }else if(k=="不及格")
    {
        GPA=0;
        return GPA;
    }
    float x=k.toFloat();

    if(x>=90)
    {
        GPA=4.00;
    }else if(x>=86&&x<=89)
    {
        GPA=3.7;
    }else if(x>=82&&x<=85)
    {
        GPA=3.30;
    }else if(x>=79&&x<=81)
    {
        GPA=3.00;
    }else if(x>=75&&x<=78)
    {
        GPA=2.7;
    }else if(x>=71&&x<=74)
    {
        GPA=2.30;
    }else if(x>=68&&x<=70)
    {
        GPA=2.00;
    }else if(x>=64&&x<=67)
    {
        GPA=1.70;
    }else if(x>=60&&x<=63)
    {
        GPA=1.3;
    }
    else{
        GPA=0;
    }
    return GPA;

}



void MainWindow::calculatePoints()
{
    GPA.clear();
    float sum_credit=0;
    float sum_GPA=0;
    //平均绩点计算公式：学分*单科绩点/总学分
    for(int i=0;i<grade.size();i++)
    {
        QString GPAvalue;
        GPAvalue=QString("%1").arg(convert_grade_to_GPA(grade[i]));
        GPA.append(GPAvalue);
        sum_GPA+=convert_grade_to_GPA(grade[i])*credit[i].toFloat();
        sum_credit+=credit[i].toFloat();
    }
    mean_GPA=QString("%1").arg(sum_GPA/sum_credit);

}
void MainWindow:: queryStudentInfo(QString str)
{
    if(!db.isOpen())
    {
        db.open();
    }
    QString queryStr=QString("SELECT * FROM t_stud_info %1").arg(str);
    QSqlQuery query(queryStr);

    while (query.next()) {
        id=query.value(0).toString();
         name = query.value(1).toString();
         profession=query.value(2).toString();
         Sclass=query.value(3).toString();
    }
}
void MainWindow::updateInfoWindow()
{
    if(mode==0)
    {
        ui->textEdit->clear();
        //设置右侧显示值
        setRightEdit(id,name,profession,Sclass);
    }else if(mode==1)
    {
        //设置右侧显示值
        setRightEdit("","","","");
    }
    draw_table();
}
void MainWindow::setRightEdit(QString id, QString name, QString profession, QString Sclass)
{
    ui->id->setText(id);
    ui->name->setText(name);
    ui->profession->setText(profession);
    ui->Sclass->setText(Sclass);
}

void MainWindow::init()
{
    for(int i=0;i<7;i++)
    {
        course.append(" ");
    }
    for(int i=0;i<7;i++)
    {
        grade.append(NULL);
    }
    for(int i=0;i<7;i++)
    {
        credit.append(NULL);
    }
    for(int i=0;i<7;i++)
    {
        GPA.append(NULL);
    }
    name=" ";
    mean_GPA="";


}

void MainWindow::draw_table()
{


        QString html=QString("<table style='margin :0 auto;' border='1px solid' cellpadding='10' align='center' >"
                            "<tr style='background-color:#b3b3b3'> <td colspan='5' align='center' >%1</td></tr>"
                             " <tr style='background-color:#00aaff'>   <td >序号</td>   <td>课程名称</td><td>成绩</td>    <td>学分</td>   <td>绩点</td> </tr> ").arg(name);
        for(int i=0;i<course.size();i++)
        {
            switch(i%2)
            {
                case 0: html.append(QString(" <tr style='background-color:#b3b3b3'>   <td> %5 </td>   <td>%1</td>   <td>%2</td>    <td>%3</td>   <td>%4</td> </tr> ")
                            .arg(course[i]).arg(grade[i]).arg(credit[i]).arg(GPA[i]).arg(i+1));
                break;
                case 1: html.append(QString(" <tr style='background-color:#00aaff'>   <td> %5 </td>   <td>%1</td>   <td>%2</td>    <td>%3</td>   <td>%4</td> </tr> ")
                                    .arg(course[i]).arg(grade[i]).arg(credit[i]).arg(GPA[i]).arg(i+1));
                break;
            }
            if((i+1)==course.size())
            {
                html.append(QString("<tr style='background-color:#00aaff'> <td colspan='5' align='center' >平均绩点:%1</td></tr"
                                    "</table> ").arg(mean_GPA));
            }
        }

        ui->textEdit->insertHtml(html);






}

void MainWindow::on_type_grade_clicked()
{
    typewidget->show();
}

void MainWindow::type_info_processing(QList<QString> courses,QList<QString> scores,QString Sname,QString Sid,QString Sprofession,QString Sgrade,QString Syear,QString Sphone)
{
    mode=0;
    //将数据导入数据库，并且显示在表格中
    id.clear();
    //看能否找到该同学，找到，则更新数据
    QString str=QString("where sName='%1'").arg(Sname);
    queryStudentInfo(str);
    if(!id.isEmpty())
    {
        //更新数据
        update_t_stud_info(Sid,Sname,Sprofession,Sgrade,Syear,Sphone);

    }else
    {
         //找不到，则插入数据
        insert_t_stud_info(Sid,Sname,Sprofession,Sgrade,Syear,Sphone);
    }
    //插入之前需要检查一下,看是否存在重复
    id=Sid;
    Sclass=Sgrade;
    profession=Sprofession;
    name=Sname;


    //插入t_stud_course_info表
    for(int i=0;i<courses.size();i++)
    {   //courseid在couseid字段
        //不存在，则插入
        getCourseIDthroughCoureName(courses.at(i));
            if(Check_duplicate(Sid,courseID))
            {
                insert_t_stud_course_info(Sid,courseID,scores.at(i),Syear,"1");
            }
    }

    //显示数据在窗口
    str=QString("where sName='%1'").arg(Sname);
    get_Stud_Score(str);
    calculatePoints();
    updateInfoWindow();

}


bool MainWindow::Check_duplicate(QString Sid,QString courseid)
{//某一课程成绩已输，则不再更新
    int n;
    if(!db.isOpen())
    {
        db.open();
    }
    QString str=QString("select count(*) from t_stud_course_info where scNumber=%1 and scCourseID=%2").arg(Sid).arg(courseid);
    QSqlQuery query(str);

    while (query.next()) {
        n = query.value(0).toInt();

    }
    qDebug()<<str;
    if(n==0)
    {
        return true;
    }else {
        return false;
    }

}




