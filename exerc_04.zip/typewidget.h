#ifndef TYPEWIDGET_H
#define TYPEWIDGET_H
#include<QLayout>
#include <QWidget>
#include<QPushButton>
#include<QLineEdit>
#include<QLabel>
class typeWidget : public QWidget
{
    Q_OBJECT
public:
    explicit typeWidget(QWidget *parent = nullptr);
private:
    //输入学号
    QLineEdit *id;
    QLabel *id_label;

    //输入姓名
    QLineEdit *name;
    QLabel *name_label;

    //输入专业
    QLineEdit *profession;
    QLabel *profession_label;

    //输入班级
    QLineEdit *grade;
    QLabel *grade_label;

    //入学年份
    QLineEdit *year;
    QLabel *year_label;


    //联系电话
    QLineEdit *phone;
    QLabel *phone_label;

    //嵌入式系统
    QLineEdit *embeded_system;
    QLabel *embeded_system_label;

    //微波技术与天线
    QLineEdit *microwave;
    QLabel *microwave_label;

    //通信原理
    QLineEdit *communication;
    QLabel *communication_label;

    //科技英语
    QLineEdit *english;
    QLabel *english_label;

    //提交按钮
    QPushButton*submit=new QPushButton;
signals:
    type_info(QList<QString>,QList<QString>,QString,QString,QString,QString,QString,QString);
public slots:
    void submit_info();
};

#endif // TYPEWIDGET_H
